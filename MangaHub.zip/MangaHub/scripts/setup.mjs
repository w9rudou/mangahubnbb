import { existsSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import { execFileSync } from "node:child_process";
if (!existsSync(".env"))
  writeFileSync(
    ".env",
    'DATABASE_URL="file:./dev.db"\nJWT_SECRET="' +
      randomBytes(48).toString("hex") +
      '"\n',
  );
process.loadEnvFile(".env");
if (
  process.env.DATABASE_URL === "file:./dev.db" &&
  !existsSync("prisma/dev.db")
)
  writeFileSync("prisma/dev.db", "");
const prisma = "node_modules/prisma/build/index.js";
for (const args of [["generate"], ["migrate", "deploy"]])
  execFileSync(process.execPath, [prisma, ...args], { stdio: "inherit" });
await import("../prisma/seed.mjs");
