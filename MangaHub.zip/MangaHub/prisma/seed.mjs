import { PrismaClient } from "@prisma/client";
import { readFileSync } from "node:fs";
const db = new PrismaClient();
try {
  const stories = JSON.parse(
    readFileSync(new URL("./stories.json", import.meta.url), "utf8"),
  );
  for (const { chapters, ...m } of stories) {
    await db.$transaction(async (tx) => {
      const manga = await tx.manga.upsert({
        where: { key: m.key },
        create: m,
        update: m,
      });
      for (const { pages, ...c } of chapters) {
        const chapter = await tx.chapter.upsert({
          where: { mangaId_number: { mangaId: manga.id, number: c.number } },
          create: { ...c, mangaId: manga.id },
          update: { title: c.title },
        });
        for (const p of pages)
          await tx.page.upsert({
            where: {
              chapterId_number: { chapterId: chapter.id, number: p.number },
            },
            create: { ...p, chapterId: chapter.id },
            update: p,
          });
      }
    });
  }
} finally {
  await db.$disconnect();
}
