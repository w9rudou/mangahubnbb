"use client";
export default function Cover({ src }: { src: string }) {
  return (
    <img
      src={src}
      alt=""
      loading="lazy"
      onError={(e) => {
        e.currentTarget.onerror = null;
        if (!e.currentTarget.src.endsWith("/art/fallback.png"))
          e.currentTarget.src = "/art/fallback.png";
      }}
    />
  );
}
