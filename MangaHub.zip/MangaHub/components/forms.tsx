"use client";
import { useActionState } from "react";
import { authenticate, interact } from "@/app/actions";
export function AuthForm({ register }: { register: boolean }) {
  const [msg, action, busy] = useActionState(authenticate, "");
  return (
    <form action={action} className="stack">
      <input
        type="hidden"
        name="mode"
        value={register ? "register" : "login"}
      />
      {register && (
        <label>
          Оқырман аты
          <input
            required
            name="name"
            autoComplete="nickname"
            minLength={2}
            maxLength={50}
          />
        </label>
      )}
      <label>
        Email
        <input type="email" required name="email" autoComplete="email" />
      </label>
      <label>
        Құпиясөз
        <input
          type="password"
          required
          minLength={register ? 8 : 1}
          name="password"
          autoComplete={register ? "new-password" : "current-password"}
        />
      </label>
      {register && <small>Кемінде 8 таңба.</small>}
      <button disabled={busy}>{register ? "Тіркелу" : "Кіру"}</button>
      <output>{msg}</output>
    </form>
  );
}
export function Interaction({
  id,
  kind,
  value,
}: {
  id: number;
  kind: "save" | "remove" | "comment" | "rate";
  value?: number;
}) {
  const [msg, action, busy] = useActionState(interact, "");
  return (
    <form className="interaction" action={action}>
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="kind" value={kind} />
      {kind === "rate" && (
        <select
          name="value"
          aria-label="Менің бағам"
          defaultValue={value || ""}
          required
        >
          <option value="" disabled>
            Баға таңдаңыз
          </option>
          {Array.from({ length: 10 }, (_, i) => (
            <option key={i} value={i + 1}>
              {i + 1} / 10
            </option>
          ))}
        </select>
      )}
      {kind === "comment" && (
        <textarea
          name="body"
          aria-label="Пікіріңіз"
          placeholder="Оқығаннан кейінгі ойыңыз…"
          required
          maxLength={1500}
        />
      )}
      <button disabled={busy}>
        {
          {
            save: "+ Сөреме қосу",
            remove: "Сөреден алу",
            comment: "Пікір жіберу",
            rate: "Бағалау",
          }[kind]
        }
      </button>
      <output aria-live="polite">{msg}</output>
    </form>
  );
}
