import Link from "next/link";
import { db } from "@/lib/db";
export default async function History({ id }: { id: number }) {
  const history = await db.progress.findMany({
    where: { userId: id },
    orderBy: { updated: "desc" },
    include: { manga: { include: { chapters: true } } },
  });
  return (
    <section>
      <h2>Жалғастыру</h2>
      {history.length ? (
        history.map((h) => {
          const c = h.manga.chapters.find((c) => c.number === h.chapterNumber);
          return (
            c && (
              <Link
                className="row"
                key={h.mangaId}
                href={"/read/" + c.id + "?page=" + h.page}
              >
                <b>{h.manga.name}</b>
                <span>
                  {c.number}-тарау · {h.page}-бет →
                </span>
              </Link>
            )
          );
        })
      ) : (
        <p>Оқи бастаған мангаңыз осында көрінеді.</p>
      )}
    </section>
  );
}
