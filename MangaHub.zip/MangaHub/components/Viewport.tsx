"use client";
import { useState, useEffect } from "react";
export default function Viewport() {
  const [open, set] = useState(false),
    [info, show] = useState("");
  useEffect(() => {
    set(localStorage.getItem("viewport") === "1");
    const update = () => {
      const w = window.innerWidth,
        u = navigator.userAgent;
      const b = /Edg/.test(u)
        ? "Edge"
        : /Firefox|FxiOS/.test(u)
          ? "Firefox"
          : /Chrome|CriOS/.test(u)
            ? "Chrome"
            : /Safari/.test(u)
              ? "Safari"
              : "Басқа";
      show(
        [
          w + " px",
          w >= 1920
            ? "1920+"
            : w >= 1280
              ? "1280+"
              : w >= 768
                ? "768+"
                : "Mobile",
          b,
        ].join(" · "),
      );
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);
  return (
    <div>
      <button
        className="quiet"
        aria-pressed={open}
        onClick={() => {
          localStorage.setItem("viewport", open ? "0" : "1");
          set(!open);
        }}
      >
        Экран ақпараты
      </button>{" "}
      {open && <output>{info}</output>}
    </div>
  );
}
