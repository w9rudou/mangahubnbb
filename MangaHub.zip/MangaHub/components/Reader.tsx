"use client";
import Link from "next/link";
import { useEffect, useState, useRef } from "react";
import { recordPage } from "@/app/actions";
import css from "./Reader.module.css";
type Mode = "single" | "double" | "scroll";
type Chapter = {
  id: number;
  number: number;
  title: string;
  mangaId: number;
  pages: { number: number; image: string; alt: string }[];
  manga: { name: string; chapters: { id: number; number: number }[] };
};
export default function Reader({
  chapter: c,
  start,
  signed,
}: {
  chapter: Chapter;
  start: number;
  signed: boolean;
}) {
  const [page, go] = useState(start),
    [mode, setMode] = useState<Mode>("single"),
    [ready, setReady] = useState(false),
    [status, setStatus] = useState("");
  const root = useRef<HTMLDivElement>(null),
    current = useRef(start),
    queue = useRef(Promise.resolve());
  const size = c.pages.length;
  const next = c.manga.chapters.find((x) => x.number > c.number),
    prev = c.manga.chapters.filter((x) => x.number < c.number).at(-1);
  useEffect(() => {
    const m = localStorage.getItem("manga-mode");
    setMode(
      m === "scroll" || m === "double" || m === "single"
        ? m
        : innerWidth >= 1000
          ? "double"
          : "single",
    );
    setReady(true);
  }, []);
  useEffect(() => {
    current.current = page;
    if (!signed || !ready) return;
    let live = true;
    queue.current = queue.current.then(async () => {
      if (!live) return;
      try {
        const ok = await recordPage(c.id, page);
        if (live)
          setStatus(
            ok ? "Прогресс сақталды" : "Прогресті сақтау үшін қайта кіріңіз.",
          );
      } catch {
        if (live) setStatus("Прогресс сақталмады.");
      }
    });
    return () => {
      live = false;
    };
  }, [page, c.id, signed, ready]);
  useEffect(() => {
    if (mode !== "scroll" || !ready) return;
    const panels = Array.from(
      root.current?.querySelectorAll<HTMLElement>("[data-page]") || [],
    );
    panels[current.current - 1]?.scrollIntoView({ block: "start" });
    const observe = () => {
      let nearest = panels[0],
        best = Infinity;
      for (const p of panels) {
        const r = p.getBoundingClientRect(),
          mid = innerHeight * 0.52;
        const distance = Math.max(0, r.top - mid, mid - r.bottom);
        if (distance < best) {
          best = distance;
          nearest = p;
        }
      }
      if (nearest) go(Number(nearest.dataset.page));
    };
    window.addEventListener("scroll", observe, { passive: true });
    return () => window.removeEventListener("scroll", observe);
  }, [mode, ready]);
  function jump(n: number) {
    go(n);
    if (mode === "scroll")
      root.current?.querySelector('[data-page="' + n + '"]')?.scrollIntoView();
  }
  const step = mode === "double" ? 2 : 1;
  return (
    <section className={css.reader}>
      <Link href={"/manga/" + c.mangaId}>← {c.manga.name}</Link>
      <h1>
        {c.number}-тарау · {c.title}
      </h1>
      <div className={css.bar}>
        <label>
          Оқу режимі{" "}
          <select
            value={mode}
            onChange={(e) => {
              const m = e.target.value as Mode;
              localStorage.setItem("manga-mode", m);
              setMode(m);
            }}
          >
            <option value="single">Бір бет</option>
            <option value="double">Қос бет</option>
            <option value="scroll">Тік оқу</option>
          </select>
        </label>
        <label>
          Бет{" "}
          <select value={page} onChange={(e) => jump(Number(e.target.value))}>
            {c.pages.map((p) => (
              <option key={p.number} value={p.number}>
                {p.number} / {size}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div ref={root} className={mode === "double" ? css.spread : css.pages}>
        {c.pages
          .filter(
            (p) =>
              mode === "scroll" || (p.number >= page && p.number < page + step),
          )
          .map((p) => (
            <img
              data-page={p.number}
              key={p.number}
              src={p.image}
              alt={p.number + "-бет. " + p.alt}
              width={720}
              height={920}
            />
          ))}
      </div>
      <div className={css.nav}>
        <button
          disabled={page === 1}
          onClick={() => jump(Math.max(1, page - step))}
        >
          ← Артқа
        </button>
        <span>
          {page}
          {mode === "double" && page < size ? "–" + (page + 1) : ""} / {size}
        </span>
        <button
          disabled={page + step > size}
          onClick={() => jump(Math.min(size, page + step))}
        >
          Алға →
        </button>
      </div>
      <small>
        {signed ? (
          status
        ) : (
          <Link href="/login">Прогресті сақтау үшін кіріңіз →</Link>
        )}
      </small>
      <div className="sectionHead">
        {prev && <Link href={"/read/" + prev.id}>← Алдыңғы тарау</Link>}
        {next ? (
          <Link href={"/read/" + next.id}>Келесі тарау →</Link>
        ) : (
          <Link href={"/manga/" + c.mangaId}>Тарауларға оралу →</Link>
        )}
      </div>
    </section>
  );
}
