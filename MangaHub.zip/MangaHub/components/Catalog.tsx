import Link from "next/link";
import { db } from "@/lib/db";
import Cover from "./Cover";
export async function catalog(q = "") {
  const all = await db.manga.findMany({
    include: { _count: { select: { chapters: true } } },
  });
  const scores = await db.rating.groupBy({
    by: ["mangaId"],
    _avg: { value: true },
    _count: { value: true },
  });
  const ratings = new Map(scores.map((x) => [x.mangaId, x]));
  return all
    .filter((m) =>
      [m.name, m.alias, m.genres].some((s) =>
        s.toLowerCase().includes(q.toLowerCase()),
      ),
    )
    .map((m) => {
      const r = ratings.get(m.id);
      return {
        ...m,
        score: r ? Number(r._avg.value) : m.externalScore,
        votes: r?._count.value || 0,
      };
    });
}
export function Cards({
  items,
}: {
  items: Awaited<ReturnType<typeof catalog>>;
}) {
  return items.length ? (
    <div className="grid">
      {items.map((m) => (
        <Link className="card" key={m.id} href={"/manga/" + m.id}>
          <div className="poster">
            <Cover src={m.cover} />
          </div>
          <small>
            {m._count.chapters ? m._count.chapters + " тарау" : "Shikimori"}
            {m.score > 0 ? " · ★ " + m.score.toFixed(1) : ""}
          </small>
          <h3>{m.name}</h3>
        </Link>
      ))}
    </div>
  ) : (
    <p>Манга табылмады.</p>
  );
}
