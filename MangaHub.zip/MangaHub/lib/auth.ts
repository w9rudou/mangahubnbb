import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { db } from "./db";
function secret() {
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32)
    throw Error("JWT_SECRET missing");
  return new TextEncoder().encode(process.env.JWT_SECRET);
}
export async function user() {
  const token = (await cookies()).get("manga_session")?.value;
  if (!token) return null;
  let id: number;
  try {
    const { payload } = await jwtVerify(token, secret(), {
      algorithms: ["HS256"],
      issuer: "mangahub",
    });
    id = Number(payload.sub);
  } catch {
    return null;
  }
  return db.user.findUnique({
    where: { id },
    select: { id: true, name: true, email: true },
  });
}
export async function login(id: number) {
  const token = await new SignJWT({})
    .setProtectedHeader({ alg: "HS256" })
    .setIssuer("mangahub")
    .setSubject(String(id))
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret());
  (await cookies()).set("manga_session", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 604800,
  });
}
