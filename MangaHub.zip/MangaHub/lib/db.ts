import { PrismaClient } from "@prisma/client";
const shared = globalThis as typeof globalThis & { mangaDb?: PrismaClient };
export const db = (shared.mangaDb ??= new PrismaClient());
