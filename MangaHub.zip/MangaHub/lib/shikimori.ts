import { db } from "./db";
const base = new URL(
  process.env.SHIKIMORI_API_URL || "https://shikimori.one/api/",
);
const fresh = new Map<string, number>();
const pending = new Map<string, Promise<void>>();
let cooldown = 0;
type Item = {
  id: number;
  name: string;
  russian?: string;
  score?: string;
  image?: { original?: string };
  description?: string;
  genres?: { name: string; russian?: string }[];
};
async function sync(path: string, detail: boolean) {
  if (Date.now() < cooldown || Date.now() < (fresh.get(path) ?? 0)) return;
  const active = pending.get(path);
  if (active) return active;
  const task = (async () => {
    try {
      const url = new URL(
        base.pathname.replace(/\/$/, "") + "/" + path,
        base.origin,
      );
      const res = await fetch(url, {
        headers: {
          "User-Agent": "MangaHub-University/1.0",
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(2500),
        cache: "no-store",
      });
      if (!res.ok) {
        if (res.status === 429) {
          const raw = res.headers.get("retry-after") || "60";
          const delay = /^\d+$/.test(raw)
            ? Number(raw) * 1000
            : Date.parse(raw) - Date.now();
          cooldown = Date.now() + Math.max(1000, delay || 60000);
        }
        throw Error(String(res.status));
      }
      const data = await res.json();
      const items: Item[] = detail ? [data] : data;
      if (!Array.isArray(items)) throw Error("Invalid catalog");
      for (const m of items) {
        if (!Number.isSafeInteger(m?.id) || typeof m.name !== "string")
          continue;
        const cover = m.image?.original
          ? new URL(m.image.original, base.origin).href
          : "/art/fallback.png";
        const fields = {
          name: m.russian || m.name,
          alias: m.name,
          cover,
          externalScore: Number(m.score) || 0,
          ...(detail
            ? {
                description: (m.description || "").replace(
                  /\[\/?[^\]]+\]/g,
                  "",
                ),
                genres: (m.genres || [])
                  .map((g) => g.russian || g.name)
                  .join(" · "),
                synced: new Date(),
              }
            : {}),
        };
        const key = "shiki-" + m.id;
        await db.manga.upsert({
          where: { key },
          create: { key, ...fields },
          update: fields,
        });
      }
      if (fresh.size > 300) fresh.clear();
      fresh.set(path, Date.now() + 600000);
    } catch {
      cooldown = Math.max(cooldown, Date.now() + 15000);
    }
  })();
  pending.set(path, task);
  try {
    await task;
  } finally {
    pending.delete(path);
  }
}
export function syncList(query = "", top = false) {
  const p = new URLSearchParams({
    limit: "24",
    order: top ? "ranked" : "popularity",
    censored: "true",
  });
  if (query) p.set("search", query);
  return sync("mangas?" + p, false);
}
export async function syncDetail(key: string, synced: Date | null) {
  if (
    /^shiki-\d+$/.test(key) &&
    (!synced || Date.now() - synced.getTime() > 86400000)
  )
    await sync("mangas/" + key.slice(6), true);
}
