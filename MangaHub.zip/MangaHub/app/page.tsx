import Link from "next/link";
import { user } from "@/lib/auth";
import { Cards, catalog } from "@/components/Catalog";
import History from "@/components/History";
export default async function Home() {
  const [me, all] = await Promise.all([user(), catalog()]);
  const readable = all.filter((m) => m._count.chapters),
    m = readable.find((x) => x.key === "almaty") || readable[0];
  return (
    <>
      {m && (
        <section className="hero">
          <div className="heroText">
            <small>Қазақша комикс · {m._count.chapters} тарау</small>
            <h1>{m.name}</h1>
            <p>{m.description}</p>
            <Link className="btn" href={"/manga/" + m.id}>
              Манганы ашу →
            </Link>
          </div>
          <img src={m.cover} alt="" fetchPriority="high" />
        </section>
      )}
      {me && <History id={me.id} />}
      <section>
        <div className="sectionHead">
          <h2>Оқуға дайын</h2>
          <Link href="/catalog">Каталогқа →</Link>
        </div>
        <Cards items={readable} />
      </section>
    </>
  );
}
