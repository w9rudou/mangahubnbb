import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { user } from "@/lib/auth";
import Reader from "@/components/Reader";
export default async function Read({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ page?: string }>;
}) {
  const id = Number((await params).id);
  if (!Number.isSafeInteger(id)) notFound();
  const c = await db.chapter.findUnique({
    where: { id },
    include: {
      pages: { orderBy: { number: "asc" } },
      manga: { include: { chapters: { orderBy: { number: "asc" } } } },
    },
  });
  if (!c || !c.pages.length) notFound();
  const me = await user(),
    stored = me
      ? await db.progress.findUnique({
          where: { userId_mangaId: { userId: me.id, mangaId: c.mangaId } },
        })
      : null;
  const p = Number(
    (await searchParams).page ||
      (stored?.chapterNumber === c.number ? stored.page : 1),
  );
  return (
    <Reader
      key={id}
      chapter={c}
      start={Number.isInteger(p) ? Math.min(c.pages.length, Math.max(1, p)) : 1}
      signed={!!me}
    />
  );
}
