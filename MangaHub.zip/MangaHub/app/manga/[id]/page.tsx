import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { syncDetail } from "@/lib/shikimori";
import { user } from "@/lib/auth";
import { Interaction } from "@/components/forms";
import Cover from "@/components/Cover";
export default async function Detail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const id = Number((await params).id);
  if (!Number.isSafeInteger(id)) notFound();
  const item = await db.manga.findUnique({ where: { id } });
  if (!item) notFound();
  await syncDetail(item.key, item.synced);
  const [m, me, stats] = await Promise.all([
    db.manga.findUniqueOrThrow({
      where: { id },
      include: {
        chapters: { orderBy: { number: "asc" } },
        comments: {
          orderBy: { id: "desc" },
          include: { user: { select: { name: true } } },
        },
      },
    }),
    user(),
    db.rating.aggregate({
      where: { mangaId: id },
      _avg: { value: true },
      _count: true,
    }),
  ]);
  const where = { userId_mangaId: { userId: me?.id || 0, mangaId: id } };
  const [saved, rating, progress] = await Promise.all([
    db.save.findUnique({ where }),
    db.rating.findUnique({ where }),
    db.progress.findUnique({ where }),
  ]);
  const chapter =
    m.chapters.find((c) => c.number === progress?.chapterNumber) ||
    m.chapters[0];
  const score = stats._avg.value || m.externalScore;
  return (
    <>
      <section className="detail">
        <div className="detailCover">
          <Cover src={m.cover} />
        </div>
        <div>
          <small>{m.genres || "Манга"}</small>
          <h1>{m.name}</h1>
          <p>{m.description || "Сипаттама әзірге қолжетімсіз."}</p>
          <p>
            <b>★ {score ? score.toFixed(1) : "—"}</b> ·{" "}
            {stats._count
              ? stats._count + " дауыс"
              : score
                ? "Shikimori"
                : "Дауыс жоқ"}
          </p>
          <div className="actions">
            {chapter && (
              <Link
                className="btn"
                href={"/read/" + chapter.id + "?page=" + (progress?.page || 1)}
              >
                {progress ? "Жалғастыру" : "Оқуды бастау"} →
              </Link>
            )}
            {me ? (
              <Interaction id={id} kind={saved ? "remove" : "save"} />
            ) : (
              <Link href="/login">Сөреге қосу үшін кіру</Link>
            )}
          </div>
        </div>
      </section>
      <section>
        <h2>Тараулар</h2>
        {m.chapters.length ? (
          m.chapters.map((c) => (
            <Link className="row" href={"/read/" + c.id} key={c.id}>
              <b>{c.number}-тарау</b>
              <span>{c.title} →</span>
            </Link>
          ))
        ) : (
          <p>Бұл манганың тараулары әзірге қосылмаған.</p>
        )}
      </section>
      <section>
        <h2>Менің бағам</h2>
        {me ? (
          <Interaction id={id} kind="rate" value={rating?.value} />
        ) : (
          <Link href="/login">Баға беру үшін кіріңіз →</Link>
        )}
      </section>
      <section>
        <h2>Пікірлер · {m.comments.length}</h2>
        {me ? (
          <Interaction id={id} kind="comment" />
        ) : (
          <Link href="/login">Пікір жазу үшін кіріңіз →</Link>
        )}
        {m.comments.map((c) => (
          <article className="comment" key={c.id}>
            <b>{c.user.name}</b>{" "}
            <time dateTime={c.created.toISOString()}>
              {c.created.toLocaleString("kk-KZ", {
                timeZone: "Asia/Almaty",
                dateStyle: "short",
                timeStyle: "short",
              })}
            </time>
            <p>{c.body}</p>
          </article>
        ))}
      </section>
    </>
  );
}
