import { Cards, catalog } from "@/components/Catalog";
import { syncList } from "@/lib/shikimori";
export default async function Catalog({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; read?: string }>;
}) {
  const params = await searchParams,
    q = String(params.q || "")
      .trim()
      .slice(0, 100);
  if (!params.read) await syncList(q);
  const items = await catalog(q);
  return (
    <section>
      <h1>Каталог</h1>
      <form className="filters">
        <input
          aria-label="Манга іздеу"
          name="q"
          defaultValue={q}
          maxLength={100}
          placeholder="Атауы немесе жанры"
        />
        <label>
          <input
            type="checkbox"
            name="read"
            value="1"
            defaultChecked={!!params.read}
          />{" "}
          Оқуға дайын
        </label>
        <button>Іздеу</button>
      </form>
      <Cards
        items={params.read ? items.filter((m) => m._count.chapters) : items}
      />
    </section>
  );
}
