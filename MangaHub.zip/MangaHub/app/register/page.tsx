import Link from "next/link";
import { AuthForm } from "@/components/forms";
export default function Page() {
  return (
    <section className="paper">
      <h1>Тіркелу</h1>
      <AuthForm register={true} />
      <Link href="/login">Аккаунтым бар →</Link>
    </section>
  );
}
