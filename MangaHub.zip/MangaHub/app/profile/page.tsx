import { redirect } from "next/navigation";
import { user } from "@/lib/auth";
import { logout } from "../actions";
import History from "@/components/History";
import Link from "next/link";
export default async function Profile() {
  const me = await user();
  if (!me) redirect("/login");
  return (
    <>
      <section>
        <small>Жеке профиль</small>
        <h1>{me.name}</h1>
        <p>{me.email}</p>
        <div className="actions">
          <Link className="btn" href="/shelf">
            Сөремді ашу
          </Link>
          <form action={logout}>
            <button className="quiet">Шығу</button>
          </form>
        </div>
      </section>
      <History id={me.id} />
    </>
  );
}
