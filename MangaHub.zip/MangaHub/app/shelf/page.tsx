import { redirect } from "next/navigation";
import Link from "next/link";
import { user } from "@/lib/auth";
import { db } from "@/lib/db";
import { catalog, Cards } from "@/components/Catalog";
export default async function Shelf() {
  const me = await user();
  if (!me) redirect("/login");
  const saved = new Set(
    (await db.save.findMany({ where: { userId: me.id } })).map(
      (s) => s.mangaId,
    ),
  );
  return (
    <section>
      <h1>Менің сөрем</h1>
      {saved.size ? (
        <Cards items={(await catalog()).filter((m) => saved.has(m.id))} />
      ) : (
        <p>
          Сөреңіз әзірге бос. <Link href="/catalog">Манга таңдау →</Link>
        </p>
      )}
    </section>
  );
}
