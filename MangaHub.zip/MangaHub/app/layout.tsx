import Link from "next/link";
import { user } from "@/lib/auth";
import Viewport from "@/components/Viewport";
import "./globals.css";
export const metadata = {
  title: "MangaHub · Манга оқу",
  description: "Қазақша комикстер мен манга каталогы",
};
export const dynamic = "force-dynamic";
export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const me = await user();
  return (
    <html lang="kk">
      <body>
        <a href="#main" className="skip">
          Мазмұнға өту
        </a>
        <header>
          <nav className="wrap">
            <Link className="brand" href="/">
              Manga<span>Hub</span>
            </Link>
            <Link href="/catalog">Каталог</Link>
            <Link href="/top">Топ</Link>
            <Link href="/shelf">Сөрем</Link>
            <Link className="account" href={me ? "/profile" : "/login"}>
              {me ? "Профиль" : "Кіру"}
            </Link>
          </nav>
        </header>
        <main id="main" className="wrap">
          {children}
        </main>
        <footer className="wrap">
          <b>MangaHub</b>
          <Viewport />
        </footer>
      </body>
    </html>
  );
}
