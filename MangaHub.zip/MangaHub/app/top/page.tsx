import Link from "next/link";
import { catalog } from "@/components/Catalog";
import { syncList } from "@/lib/shikimori";
export default async function Top() {
  await syncList("", true);
  const rows = (await catalog()).sort(
    (a, b) =>
      b.score - a.score || b.votes - a.votes || a.name.localeCompare(b.name),
  );
  return (
    <section>
      <h1>Манга рейтингі</h1>
      <p>
        Оқырман бағаларының орташа мәні. Алғашқы дауысқа дейін Shikimori бағасы
        көрсетіледі.
      </p>
      {rows.map((m, i) => (
        <Link className="row" key={m.id} href={"/manga/" + m.id}>
          <span className="rank">{i + 1}</span>
          <b>{m.name}</b>
          <small>
            {m.votes ? m.votes + " дауыс" : m.score ? "Shikimori" : "Дауыс жоқ"}
          </small>
          <strong>{m.score ? m.score.toFixed(1) : "—"}</strong>
        </Link>
      ))}
    </section>
  );
}
