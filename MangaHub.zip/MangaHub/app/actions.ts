"use server";
import { db } from "@/lib/db";
import { login, user } from "@/lib/auth";
import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { Prisma } from "@prisma/client";

export async function authenticate(_: string, f: FormData) {
  const email = String(f.get("email") || "")
    .trim()
    .toLowerCase();
  const password = String(f.get("password") || "");
  const name = String(f.get("name") || "").trim();
  if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
    email.length > 254 ||
    Buffer.byteLength(password) > 72
  )
    return "Email мен құпиясөзді тексеріңіз.";
  let id: number;
  if (f.get("mode") === "register") {
    if (name.length < 2 || name.length > 50 || password.length < 8)
      return "Атыңыз 2–50 таңба, құпиясөз кемінде 8 таңба болуы керек.";
    const hash = await bcrypt.hash(password, 12);
    try {
      id = (await db.user.create({ data: { email, name, hash } })).id;
    } catch (e) {
      if (
        e instanceof Prisma.PrismaClientKnownRequestError &&
        e.code === "P2002"
      )
        return "Бұл email тіркелген.";
      throw e;
    }
  } else {
    const found = await db.user.findUnique({ where: { email } });
    if (!found || !(await bcrypt.compare(password, found.hash)))
      return "Email немесе құпиясөз қате.";
    id = found.id;
  }
  await login(id);
  redirect("/profile");
}
export async function logout() {
  (await cookies()).delete("manga_session");
  redirect("/");
}
export async function interact(_: string, f: FormData) {
  const me = await user();
  if (!me) redirect("/login");
  const mangaId = Number(f.get("id")),
    userId = me.id;
  if (
    !Number.isSafeInteger(mangaId) ||
    !(await db.manga.findUnique({ where: { id: mangaId } }))
  )
    return "Манга табылмады.";
  const where = { userId_mangaId: { userId, mangaId } };
  switch (f.get("kind")) {
    case "rate": {
      const value = Number(f.get("value"));
      if (!Number.isInteger(value) || value < 1 || value > 10)
        return "1–10 аралығындағы бағаны таңдаңыз.";
      await db.rating.upsert({
        where,
        create: { userId, mangaId, value },
        update: { value },
      });
      break;
    }
    case "comment": {
      const body = String(f.get("body") || "").trim();
      if (!body || body.length > 1500)
        return "Пікір 1–1500 таңбадан тұруы керек.";
      await db.comment.create({ data: { userId, mangaId, body } });
      break;
    }
    case "save":
      await db.save.upsert({ where, create: { userId, mangaId }, update: {} });
      break;
    case "remove":
      await db.save.deleteMany({ where: { userId, mangaId } });
      break;
    default:
      return "Әрекет белгісіз.";
  }
  for (const path of ["/manga/" + mangaId, "/top", "/shelf", "/profile", "/"])
    revalidatePath(path);
  return "Сақталды.";
}
export async function recordPage(chapterId: number, page: number) {
  const me = await user();
  if (!me) return false;
  if (!Number.isSafeInteger(chapterId) || !Number.isSafeInteger(page))
    return false;
  const found = await db.page.findUnique({
    where: { chapterId_number: { chapterId, number: page } },
    include: { chapter: true },
  });
  if (!found) return false;
  const { mangaId, number: chapterNumber } = found.chapter;
  await db.progress.upsert({
    where: { userId_mangaId: { userId: me.id, mangaId } },
    update: { chapterNumber, page },
    create: { userId: me.id, mangaId, chapterNumber, page },
  });
  return true;
}
