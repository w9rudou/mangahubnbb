import Link from "next/link";
import { AuthForm } from "@/components/forms";
export default function Page() {
  return (
    <section className="paper">
      <h1>Кіру</h1>
      <AuthForm register={false} />
      <Link href="/register">Тіркелу →</Link>
    </section>
  );
}
